# -*- coding:utf-8 -*-

def calc_tax():
    print("print tax")

def calc_shipping():
    print("print shipping")
