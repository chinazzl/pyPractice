print("init economy construcetor")
